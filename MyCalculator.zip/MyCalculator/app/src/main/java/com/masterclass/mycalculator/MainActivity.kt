package com.masterclass.mycalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.ArithmeticException
import java.text.NumberFormat

class MainActivity : AppCompatActivity() {

    var lastNumeric: Boolean = false
    var lastDot: Boolean = false
    var lastOp: Boolean = false
    var overflow: Boolean = false
    var savedInput: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun onDigit(view: View) {
        if (!overflow) {
            if (!lastOp)
                tvInput.append((view as Button).text)
            else {
                tvInput.setText((view as Button).text)
                lastOp = false
            }
            lastNumeric = true
        }
    }
    fun onClear(view: View){
       tvInput.text = ""
        lastNumeric = false
        lastDot = false
        overflow = false
    }

    fun onDecimalPoint(view: View){
        if(lastNumeric && !lastDot && !overflow){
            tvInput.append((view as Button).text)
            lastNumeric = false
            lastDot = true
        }
    }

    private fun isOpSignAdded(value: String) : Boolean{
        return if(value.startsWith("-"))
            false
        else {
            value.contains("+") || value.contains("-")
            || value.contains("*") || value.contains("/")
        }
    }

    fun onOperator(view: View){
        if(tvInput.text.length >= 11) {
            saveInput(tvInput.text.toString())
            onClear(view)
            tvInput.append("ANS" + (view as Button).text)
        }
        else if(lastNumeric && !isOpSignAdded(tvInput.text.toString()) && !overflow){
            tvInput.append((view as Button).text)
            lastNumeric = false
            lastDot = false
        }
    }

    fun onEqual(view: View){

        if(lastNumeric && !overflow){

            if (savedInput.length >= 1)
                tvInput.text = tvInput.text.toString().substring(3)

            var tvValue: String = savedInput + tvInput.text.toString()
            var prefix: String = ""

            try{

                if(tvValue.startsWith("-")){
                    prefix = "-"
                    tvValue = tvValue.substring(1)
                }

                when {
                    tvValue.contains("-") -> {
                        tvInput.text = operate(prefix, tvValue, '-')
                    }
                    tvValue.contains("+") -> {
                        tvInput.text =  operate(prefix, tvValue, '+')
                    }
                    tvValue.contains("*") -> {
                        tvInput.text = operate(prefix, tvValue, '*')
                    }
                    tvValue.contains("/") -> {
                        tvInput.text = operate(prefix, tvValue, '/')
                    }
                }

                saveInputReset()

            }catch (e:ArithmeticException){
                e.printStackTrace()
            }
        }
    }

    private fun operate(prefix : String, text: String, delimiter: Char) : String{

        val splitValue = text.split(delimiter)

        var num1 = splitValue[0]
        var num2 = splitValue[1]

        if(!prefix.isEmpty()) {
            num1 = prefix + num1
        }

        return when(delimiter){
            '-' -> fixPrecision((num1.toDouble() - num2.toDouble()).toString())
            '+' -> fixPrecision((num1.toDouble() + num2.toDouble()).toString())
            '*' -> fixPrecision((num1.toDouble() * num2.toDouble()).toString())
            '/' -> fixPrecision((num1.toDouble() / num2.toDouble()).toString())
            else -> "Error"
        }
    }
    private fun fixPrecision(value: String) : String{

        var result: String = value

        if(result.contains("E") && result.length > 12) {
            overflow = true
            return "Overflow"
        }

        return if(result.toDouble() != 0.0) {
           // Toast.makeText(this,"LEN: ${result.length}, NUM: $result",Toast.LENGTH_LONG).show()
            while ((result.endsWith('0') || result.length > 12) && !result.contains("E")){

                result = result.substring(0, result.lastIndex)

            }
           // Toast.makeText(this,"NEW LEN: ${result.length}, NEW NUM: $result",Toast.LENGTH_LONG).show()
            if(result.endsWith('.'))
                result = result.substring(0,result.lastIndex)
            result
        } else "0"
    }


    private fun saveInput(input: String){
        savedInput = input
    }
    private fun saveInputReset(){
        savedInput = ""
    }
}
